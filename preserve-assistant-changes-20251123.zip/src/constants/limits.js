export const MAX_ROWS = 150;
export const FUZZY_BANK_AUTO = 0.9;
export const FUZZY_SUPPLIER_AUTO = 0.9;
export const FUZZY_SUPPLIER_SUGGEST = 0.8;
export const SUPPLIER_VARIANTS_KEY = "bgl_supplier_variants";
