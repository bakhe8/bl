✅ أوّلًا: ما هي هذه الملفات وكيف تُستخدم؟
1) ملف suppliers_index.json

هذا الملف يحتوي على قاعدة المعرفة المتعلمة من برنامجك—أسماء مورّدين ظهرت في ملفات ضمانات سابقة، مع:

الاسم الرسمي

عدد مرات التكرار

الاختصارات (aliases)

الأخطاء الإملائية المتكررة

📌 مثال فعلي من الملف:
شركة فاروق ومامون تمر وشركاهما ظهرت 15 مرة ولها Alias واحد


suppliers_index

هذا يجعلها مورد قوي التعريف (High Confidence).

2) ملف companies.json

هذا الملف يحتوي على أسماء الموردين من النظام—غالبًا من إدارة العقود والمشتريات أو ERP.

هذه القائمة هي “الأسماء الصحيحة” أو “الداتا الرسمية”.

3) ملف companies_cleaned.json

نسخة من نفس الموردين بعد عملية تنظيف:

إزالة التكرارات

توحيد الهجاء

إزالة التنوين

إزالة الهمزات

تطبيع الأسماء

هذا الملف مهم جدًا لأنه:

هو الذي تبدأ به عملية pipeline (Normalization → Fuzzy → Matching).

🎯 إذًا… كيف تستفيد من الملفات عمليًا داخل المحرك؟

سأعطيك خارطة طريق تنفيذ حقيقية:

🧠 المرحلة 1 — بناء “بنك الموردين الرسمي”

اجمع:

companies.json

companies_cleaned.json

ثم أنشئ هيكل واحد:

officialSuppliers = companies_cleaned.map(s => ({
   canonical: s,  
   normalized: normalizeName(s),
   short: [],      // تُضاف لاحقًا
   score: 1.0      // ثقة 100%
}))

🧠 المرحلة 2 — إضافة الذكاء من suppliers_index.json

هذا الملف هو “تاريخ أخطاء المستخدمين” أو “تعلم من الماضي”.

مثال فعلي:

"canonical": "شركة مكتب الكمال للاستيراد المحدودة",
"aliases": ["شركة مكتب الكمال للإستيراد المحدودة"]


suppliers_index

يتم دمج aliases مباشرة في النظام:

for (item of suppliers_index) {
    let s = officialSuppliers.find(x => normalize(x.canonical) == normalize(item.canonical));
    if (s) {
        s.aliases.push(...item.aliases);
        s.score += item.count * 0.1;   // تعزيز الثقة
    }
}


🎯 المعنى:
كلما تكرر اسم مورد في ملفاتك، يصبح أسهل وأسرع في المطابقة.

🧠 المرحلة 3 — بناء قاعدة “الاختصارات العربية والإنجليزية”

ملاحظة مهمة: لا نحذف كلمات الكيان (شركة/مؤسسة/المحدودة/ذ.م.م)، بل نبقيها كما هي ونكتفي بتوحيد الحروف والمسافات والتشكيل، لأنها جزء من الاسم القانوني.

من البيانات الحقيقية:

مثال:

“شركة الفيصلية للأنظمة الطبية”

alias: “شركة الفيصلية للانظمة الطبية”


suppliers_index

يُضاف:

الفيصلية

الأنظمة الطبية

الفيصلية طبية

FPC (إن وجدت)

Faisaliah Medical

الخوارزمية تبني كل هذا تلقائيًا:

short.push(
   extractKeywords(arabicName),
   removeStopWords(arabicName),
   englishTransliteration(arabicName),
   aliases...
);

🧠 المرحلة 4 — بناء الماتشنغ

عند قراءة اسم المورد من Excel:

1) normalizeName

إزالة:

شركة

مؤسسة

المحدودة

ذ.م.م

للتجارة

medical / trading / company

ال التعريف

التنوين

الهمزات

2) fuzzy compare

باستخدام Jaro-Winkler أو Damerau-Levenshtein

3) حساب احتمالية

باستخدام نقاط:

match with canonical

match with alias

match with cleaned keyword

match with english transliteration

🧠 المرحلة 5 — إضافة المستندات (ملف guarantees) كمصدر تعلم إضافي

من ملف guarantees (المرفقات التي تحتوي على اسم المورد داخل ملف docx) مثل:

"company": "شركة الفيصلية للانظمة الطبية" 


companies_cleaned

هذه أسماء من واقع المعاملات، تُستخدم لتغذية:

suppliers_index.json

aliases

keyword extraction

تحسين التطبيع normalization

🧠 المرحلة 6 — دمج النظام بالكامل في learningEngine
learningEngine يقوم بـ:

قراءة Excel supplier_name

normalize supplier_name

البحث داخل قاعدة الموردين official suppliers

البحث داخل aliases

تطبيق fuzzy matching

استخراج احتمالية

اقتراح أفضل 3 شركات

التعلم في حال وافق المستخدم

🧠 المرحلة 7 — استفادة عملية من كل ملف:
الملف	الفائدة	كيف يُستخدم؟
companies.json	الأسماء الرسمية	المصدر الأساسي
companies_cleaned.json	نسخة مطبّعة	matching سريع
suppliers_index.json	تاريخ أخطاء المستخدمين	توليد aliases
ملف ضمانات البنوك	مصادر تعلم جديدة	استخراج أسماء الموردين
🔥 مثال عملي كامل (من ملفاتك)
لو جاء في Excel:
شركة الفيصلية لأنظمة الطبية

normalize:

→ "فيصلية انظمة طبية"

matching:

canonical: “شركة الفيصلية للأنظمة الطبية”
normalized: “فيصلية انظمة طبية”

✔ exact-normalized → 100%

alias:

"شركة الفيصلية للانظمة الطبية"


✔ match → 98%

learned from guarantee:

company: "شركة الفيصلية للأنظمة الطبية"


companies_cleaned

✔ match → +confidence

النتيجة:

Matching → Auto (HIGH CONFIDENCE)
